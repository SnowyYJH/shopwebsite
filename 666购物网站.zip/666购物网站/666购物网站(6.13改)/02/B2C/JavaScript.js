﻿<form ...>
</form>
    <script type="text/javascript">
        document.getElementById('<%= HiddenField1.ClientID %>').value = window.screen.height;
</script>